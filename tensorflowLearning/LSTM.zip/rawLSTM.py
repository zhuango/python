"""
    @author: samuel ko
    @date: 2018/12/18
    @target: 训练一个只带一层LSTM的TF模型
    @ref: 作者：谢小小XH
          来源：CSDN
          原文：https://blog.csdn.net/xierhacker/article/details/78772560
"""

import numpy as np
import tensorflow as tf
from tensorflow.python import keras
from tensorflow.python.keras import backend as K
from tensorflow.python.keras.preprocessing import sequence
from tensorflow_model_optimization.python.core.sparsity.keras import prune
from tensorflow_model_optimization.python.core.sparsity.keras import pruning_callbacks
from tensorflow_model_optimization.python.core.sparsity.keras import pruning_schedule
from tensorflow_model_optimization.python.core.sparsity.keras import pruning_wrapper
import LSTMtensorflow as quan
import quantize_weights as quan_w

max_features = 20000
maxlen = 100  # cut texts after this number of words
batch_size = 100
vector_length = 100
hidden_size = 100

print("Loading data...")
(x_train,
 y_train), (x_test,
            y_test) = keras.datasets.imdb.load_data(num_words=max_features)

print(len(x_train), "train sequences")
print(len(x_test), "test sequences")

print("Pad sequences (samples x time)")
x_train = sequence.pad_sequences(x_train, maxlen=maxlen)
x_test = sequence.pad_sequences(x_test, maxlen=maxlen)
print("x_train shape:", x_train.shape)
print("x_test shape:", x_test.shape)

y_train = np.reshape(y_train, (y_train.shape[0], 1))
y_test = np.reshape(y_test, (y_test.shape[0], 1))

inputs = tf.placeholder(shape=(None, maxlen), dtype=tf.int32, name='Inputs')
labels = tf.placeholder(shape=(None, 1), dtype=tf.float32, name="Labels")
gold = tf.placeholder(shape=(None, 1), dtype=tf.int64, name="Labels2")


with tf.variable_scope("ibm", default_name="zhuang", custom_getter=quan_w.quantize_getter):
    c = tf.get_variable("embeddings", initializer=  np.array(np.random.uniform(-1, 1, [max_features, vector_length]), dtype=np.float32), dtype=tf.float32)
    b = tf.nn.embedding_lookup(c, inputs)

    lstm_cell = quan.QLSTMCell(num_units=hidden_size)
    # initialize to zero
    init_state = lstm_cell.zero_state(batch_size=batch_size, dtype=tf.float32)

    output, state = tf.nn.dynamic_rnn(
        cell=lstm_cell,
        inputs=b,
        dtype=tf.float32,
        initial_state=init_state,
    )

    print("output.shape:", output.shape)
    print("len of state tuple", len(state))
    print("state.h.shape:", state.h.shape)
    print("state.c.shape:", state.c.shape)

    # output = tf.layers.dense(output, 26)
    output = tf.layers.dense(state.h, 1, name="Outputs")

loss = tf.nn.sigmoid_cross_entropy_with_logits(labels=labels, logits=output)

correctPred = tf.less_equal(0.5, tf.sigmoid(output))
correctPred = tf.equal(tf.cast(correctPred, tf.int64), gold)
accuracy = tf.reduce_sum(tf.cast(correctPred, tf.int64))

optimizer = tf.train.AdamOptimizer(0.001).minimize(loss=loss)
init = tf.global_variables_initializer()
saver = tf.train.Saver(max_to_keep=5)
    #-------------------------------------------Define Session---------------------------------------#
with tf.Session() as sess:
    sess.run(init)
    for epoch in range(1, 3+1):
        train_losses = []
        print("epoch:", epoch)
        #for j in range(25000//batch_size):
        for j in range(5000//batch_size):
            _, train_loss = sess.run(
                    fetches=(optimizer, loss),
                    feed_dict={
                            inputs: x_train[j*batch_size: j*batch_size + batch_size],
                            labels: y_train[j*batch_size: j*batch_size + batch_size]
                        }
            )
            train_losses.append(train_loss)
        print("average training loss:", np.sum(train_losses) / len(train_losses*batch_size))
    saver.save(sess, "model/simple_lstm")

    nextBatch, nextBatchLabels = x_test, y_test
    acc = 0
    for j in range(len(x_test)//batch_size):
        this_batch_acc = sess.run(accuracy,
            feed_dict={
                inputs: x_test[j*batch_size: j*batch_size + batch_size], 
                gold:   y_test[j*batch_size: j*batch_size + batch_size]
            }
        )
        acc += this_batch_acc
    print("Accuracy :", (acc / len(x_test) * 100))
