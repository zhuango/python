import tensorflow as tf

def quantize(x, k, t = False):
    n = float(2 ** k - 1)

    @tf.custom_gradient
    def _quantize(x):
        return tf.round(x * n) / n, lambda dy: dy
    
    return _quantize(x)

def quant_linear(x, k):
    n = float(2 ** k - 2)
    @tf.custom_gradient
    def _quantize(x):
        return tf.round(x * n) / n, lambda dy: dy
    
    return _quantize(x)

def fw(x, bitW):
    # if bitW == 32:
    #     return x

    if bitW == 1:
        E = tf.stop_gradient(tf.reduce_mean(tf.abs(x)))

        @tf.custom_gradient
        def _sign(x):
            return tf.where(tf.equal(x, 0), tf.ones_like(x), tf.sign(x), tf.sign(x / E)) * E, lambda dy:dy
        
        return _sign(x)
    
    init = tf.constant_initializer(1.0)
    thr = tf.get_variable(x.op.name + "_thr", [], initializer= init, trainable=True)

    x_max = tf.reduce_max(tf.abs(x))
    x = tf.clip_by_value(x, -x_max * thr, x_max * thr)
    x = x / (x_max * thr) * 0.5 + 0.5

    return (2 * quant_linear(x, bitW) - 1) * (x_max * thr)

def fa(x, bitA):
    if bitA == 32:
        return x
    tf.logging.info('Quantize {} A to {} bit'.format(x.op.name, bitA))
    return quantize(x, bitA)

BITW = 32

def quantize_getter(getter, name, *args, **kwargs):
    if name.endswith("bias") or name.endswith("embeddings") or name.endswith("kernel"):
        print("QQQQQQQQQQQQQQQQQQQQQQQQ", name)
        tf.logging.info("Quantize {} W to {}bit".format(name, BITW))
        return fw(getter(name, *args, **kwargs), BITW)
    else:
        return getter(name, *args, **kwargs)

def quantize_getter_nogetter(name, *args, **kwargs):
    if name.endswith("kernel"):
        tf.logging.info("Quantize {} W to {}bit".format(name, BITW))
        return fw(base_layer_utils.make_variable(name, *args, **kwargs), BITW)
    else:
        return base_layer_utils.make_variable(name, *args, **kwargs)